package com.testxpress.framework.testng.services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WindowsDesktopAutomationApplicationTests {

	@Test
	void contextLoads() {
	}

}
